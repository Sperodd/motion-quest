
extends CharacterBody2D

# 이동 설정
@export var speed: float = 200.0
@export var jump_power: float = -650.0
@export var running: bool = true

@onready var anim = $AnimatedSprite2D
@export var bullet_scene: PackedScene

# 중력 설정
var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")


var default_speed: float
var default_gravity: float


func _ready():
	default_speed = speed
	default_gravity = gravity


func _physics_process(delta):
	# 중력 적용
	if not is_on_floor():
		velocity.y += gravity * delta

	# 달리기 상태
	if running:
		velocity.x = speed
	else:
		velocity.x = 0

	# 이동 처리
	move_and_slide()


func dash():
	running = true

	gravity = 0
	speed = 300.0
	velocity.y = 0

	await get_tree().create_timer(0.5).timeout
	reset_action()

func jump():
	if not is_on_floor():
		return

	velocity.y = jump_power
	anim.play("jump")

func crouch():
	speed = 50.0
	anim.play("crouch")

func shoot():
	var bullet = bullet_scene.instantiate()
	bullet.global_position = global_position
	bullet.direction = Vector2.RIGHT

	get_tree().current_scene.add_child(bullet)

func reset_action():
	speed = default_speed
	gravity = default_gravity
	running = true
	anim.play("run")

	anim.play("run")
