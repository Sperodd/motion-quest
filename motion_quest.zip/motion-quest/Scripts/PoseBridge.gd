extends Node
## Add as an Autoload named PoseBridge (Godot 4 Web export).
## Reads the host page's PoseTCN JSON snapshot; no second camera or socket.

signal pose_changed(class_id: String)
signal counts_changed(counts: Dictionary)
signal snapshot_updated(snapshot: Dictionary)

var snapshot: Dictionary = {}
var _elapsed: float = 0.0

func _ready() -> void:
	if not OS.has_feature("web"):
		push_warning("PoseBridge requires a Web export inside the Pose Lab page.")
		set_process(false)

func _process(delta: float) -> void:
	_elapsed += delta
	if _elapsed < 0.1:
		return
	_elapsed = 0.0
	# Same page or a same-origin iframe. A separate tab does not share window.
	var raw = JavaScriptBridge.eval("""
		(() => {
		  try {
		    const bridge = window.PoseTCN || window.parent.PoseTCN;
			return bridge ? bridge.getSnapshotJson() : '';
		  } catch (_) { return ''; }
		})()
	""")
	var next: Dictionary = {}
	if raw is String and not raw.is_empty():
		var parsed = JSON.parse_string(raw)
		if parsed is Dictionary and parsed.get("version", 0) == 1:
			next = parsed
	var previous_pose := get_pose()
	var previous_counts := get_counts()
	snapshot = next
	if previous_pose != get_pose():
		pose_changed.emit(get_pose())
	if previous_counts != get_counts():
		counts_changed.emit(get_counts())
	snapshot_updated.emit(snapshot.duplicate(true))

func is_stream_connected() -> bool:
	return bool(snapshot.get("connected", false))

func get_pose() -> String:
	var pose = snapshot.get("pose")
	return str(pose.get("class_id", "")) if pose is Dictionary else ""

func get_score() -> float:
	var pose = snapshot.get("pose")
	return float(pose.get("score", 0.0)) if pose is Dictionary else 0.0

func get_counts() -> Dictionary:
	var counter: Dictionary = snapshot.get("counter", {})
	var counts: Dictionary = counter.get("counts", {})
	return counts.duplicate(true)

func get_count(class_id: String) -> int:
	return int(get_counts().get(class_id, 0))

func is_counter_enabled() -> bool:
	var counter: Dictionary = snapshot.get("counter", {})
	return bool(counter.get("enabled", false))
