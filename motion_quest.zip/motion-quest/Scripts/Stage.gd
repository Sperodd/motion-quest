extends Button

func _on_pressed():
	get_tree().change_scene_to_file("res://Scene/Stage1.tscn")
	print_debug("pushed")
