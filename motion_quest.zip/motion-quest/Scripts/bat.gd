extends CharacterBody2D

@export var speed: float = 100.0
@export var turn_interval: float = 1.0

@onready var sprite = $AnimatedSprite2D

var direction: int = -1
var elapsed_time: float = 0.0

func _physics_process(delta):
	elapsed_time += delta

	if elapsed_time >= turn_interval:
		direction *= -1
		elapsed_time = 0.0

	velocity.x = direction * speed
	move_and_slide()

	sprite.flip_h = direction > 0
