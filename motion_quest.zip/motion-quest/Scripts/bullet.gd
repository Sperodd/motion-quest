extends Area2D

@export var speed: float = 200.0
var direction: Vector2 = Vector2.RIGHT

func _physics_process(delta):
	position += direction * speed * delta

func _on_body_entered(body):
	if body.name == "Player":
		return
	if body.name == "Bat":
		body.queue_free()
		queue_free()
		return
	queue_free()
