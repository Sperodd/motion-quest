extends Node2D

@onready var panel = $Panel

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	panel.hide()


func show_panel() -> void:
	panel.show()



func _on_button_pressed() -> void:
	get_tree().reload_current_scene()

func _on_button_2_pressed() -> void:
	get_tree().change_scene_to_file("res://Scene/MainMenu.tscn")
