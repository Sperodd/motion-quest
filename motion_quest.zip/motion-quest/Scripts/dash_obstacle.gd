extends Node

@export var goal = 1
var work: String = "m03"
var waiting_player: CharacterBody2D = null

var start_count: int = 0
var current_count: int = 0

var message: String = "Inline lunge \n" + str(goal-current_count) + " remains!"
@onready var area = $Area2D
@onready var notice_panel = $NoticePanel

func _ready() -> void:
	notice_panel.set_text(message)
	
func _process(_delta: float) -> void:
	if not is_instance_valid(waiting_player):
		waiting_player = null
		return

	message = "Inline lunge \n" + str(goal-current_count) + " remains!"
	notice_panel.set_text(message)
	
	current_count = PoseBridge.get_count(work) - start_count
	if current_count < goal:
		return

	var player = waiting_player
	waiting_player = null
	
	player.dash()
	notice_panel.hide_panel()


func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.name != "Player":
		return

	if is_instance_valid(waiting_player):
		return

	start_count = PoseBridge.get_count(work)
	waiting_player = body
	body.speed = 0
	notice_panel.show_panel()
