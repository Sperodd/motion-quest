extends Node2D

func _on_area_2d_body_exited(body: Node2D) -> void:
	if body.name == "Player":
		var ClearPanel = get_parent().get_node("ClearPanel")
		ClearPanel.show_panel()
		body.speed = 0
