extends Node2D

@onready var panel = $Panel
@onready var label = $Panel/Label

func _ready():
	hide_panel()

func set_text(message: String):
	label.text = message

func show_panel():
	panel.show()

func hide_panel():
	panel.hide()
