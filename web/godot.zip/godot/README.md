Godot Web 내보내기의 index.html 및 관련 파일 전체를 이 폴더에 넣으세요.
연결 설정은 ../../godot/README.md를 참고하세요.
